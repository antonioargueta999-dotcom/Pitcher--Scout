import { useState } from "react";

const GAMES = [
  {
    id: 0, label: "SEA @ STL", time: "2:15 PM",
    awayTeam: "SEA", homeTeam: "STL", awayWinPct: 58, homeWinPct: 42,
    awayColor: "#005C5C", homeColor: "#C41E3A",
    bestPlay: { name: "Bryan Woo", play: "MORE 5 Ks", note: "Línea PP 0.5 menor · STL K% elevado" },
    pitchers: [
      { id: 0, name: "Bryan Woo", team: "SEA", teamColor: "#005C5C", number: "#22", hand: "R", bp: { fd: 34.7, dk: 19.8, bf: 22.8, inn: 5.71, r: 1.80, h: 4.47, k: 6.11, bb: 1.30 }, innDist: [0,1,4,7,12,16,18,16,11,8,8], props: { k: { line: 5.5, proj: 5.4, side: "Under", oOdds: "+102", uOdds: "-136", record: "1-3", coverProb: 55, ev: -4, rating: 2 }, er: { line: 1.5, oOdds: "-160", uOdds: "+123" }, h: { line: 5.5, oOdds: "+123", uOdds: "+115" } }, pp: { line: 5 }, verdict: "MORE", confidence: 78, verdictNote: "Línea PP (5) medio punto menor. STL K% alto. 🔥", kPct: [{ batter: "I. Herrera", rc: -26, k: 19, hand: "R" }, { batter: "A. Burleson", rc: -28, k: 22, hand: "L" }, { batter: "P. Pages", rc: -35, k: 25, hand: "R" }, { batter: "N. Church", rc: -40, k: 30, hand: "L" }] },
      { id: 1, name: "M. Liberatore", team: "STL", teamColor: "#C41E3A", number: "#32", hand: "L", bp: { fd: 22.1, dk: 11.0, bf: 22.7, inn: 5.27, r: 2.54, h: 5.42, k: 3.92, bb: 1.67 }, innDist: [3,8,15,18,19,16,12,6,3,1,1], props: { k: { line: 4.5, proj: 4.3, side: "Under", oOdds: "+114", uOdds: "-152", record: "1-4", coverProb: 57, ev: -5, rating: 2 }, er: { line: 2.5, oOdds: "+113", uOdds: "-137" }, h: { line: 4.5, oOdds: "-130", uOdds: "+117" } }, pp: { line: 4 }, verdict: "LESS", confidence: 62, verdictNote: "SEA K% reducido vs Liberatore. Historial 4/5 bajo la línea. ⚠️", kPct: [{ batter: "R. Arozarena", rc: 6, k: -31, hand: "R" }, { batter: "J. Rodriguez", rc: 0, k: -28, hand: "R" }, { batter: "C. Young", rc: -6, k: -21, hand: "L" }] },
    ],
  },
  {
    id: 1, label: "CLE @ TOR", time: "3:07 PM",
    awayTeam: "CLE", homeTeam: "TOR", awayWinPct: 44, homeWinPct: 56,
    awayColor: "#E31937", homeColor: "#134A8E",
    bestPlay: { name: "Kevin Gausman", play: "MORE 5 Ks", note: "Proyección 5.7 supera PP de 5 · EV +9%" },
    pitchers: [
      { id: 0, name: "Joey Cantillo", team: "CLE", teamColor: "#E31937", number: "#54", hand: "L", bp: { fd: 25.5, dk: 13.8, bf: 21.3, inn: 5.07, r: 2.21, h: 4.39, k: 4.83, bb: 1.79 }, innDist: [1,5,8,13,17,19,15,10,6,3,2], props: { k: { line: 4.5, proj: 4.6, side: "Over", oOdds: "-114", uOdds: "-114", record: "2-3", coverProb: 51, ev: -4, rating: 2 }, er: { line: 2.5, oOdds: "+116", uOdds: "-140" }, h: { line: 4.5, oOdds: "-106", uOdds: "+110" } }, pp: { line: 4.5 }, verdict: "MORE", confidence: 53, verdictNote: "Proyección (4.6) supera ligeramente la línea. EV negativo ⚠️", kPct: [{ batter: "V. Guerrero Jr.", rc: 0, k: 31, hand: "R" }, { batter: "E. Clement", rc: -2, k: 33, hand: "R" }] },
      { id: 1, name: "Kevin Gausman", team: "TOR", teamColor: "#134A8E", number: "#34", hand: "R", bp: { fd: 34.3, dk: 19.4, bf: 23.9, inn: 5.98, r: 2.03, h: 4.53, k: 6.05, bb: 1.40 }, innDist: [1,2,4,7,12,16,17,14,12,8,7], props: { k: { line: 5.5, proj: 5.7, side: "Over", oOdds: "+116", uOdds: "-154", record: "2-3", coverProb: 51, ev: 9, rating: 3 }, er: { line: 2.5, oOdds: "+132", uOdds: "-165" }, h: { line: 4.5, oOdds: "-115", uOdds: "+100" } }, pp: { line: 5 }, verdict: "MORE", confidence: 72, verdictNote: "Proyección 5.7 supera BPros 5.5 y PP 5. EV +9%. 🔥", kPct: [{ batter: "J. Ramirez", rc: -9, k: 25, hand: "S" }, { batter: "B. Rocchio", rc: -14, k: 28, hand: "S" }] },
    ],
  },
  {
    id: 2, label: "MIA @ SF", time: "4:05 PM",
    awayTeam: "MIA", homeTeam: "SF", awayWinPct: 45, homeWinPct: 55,
    awayColor: "#00A3E0", homeColor: "#FD5A1E",
    bestPlay: { name: "Eury Perez", play: "MORE 5 Ks", note: "EV +12% · Cover 66% · Δ0.6" },
    pitchers: [
      { id: 0, name: "Eury Perez", team: "MIA", teamColor: "#00A3E0", number: "#39", hand: "R", bp: { fd: 30.3, dk: 16.9, bf: 21.8, inn: 5.28, r: 1.85, h: 4.16, k: 5.57, bb: 1.92 }, innDist: [1,2,4,10,14,19,19,13,9,6,4], props: { k: { line: 4.5, proj: 5.6, side: "Over", oOdds: "-144", uOdds: "+108", record: "2-3", coverProb: 66, ev: 12, rating: 4 }, er: { line: 2.5, oOdds: "+121", uOdds: "-157" }, h: { line: 4.5, oOdds: "+110", uOdds: "-111" } }, pp: { line: 5 }, verdict: "MORE", confidence: 80, verdictNote: "Proyección 5.6 supera PP de 5 por Δ0.6. EV +12% y cover 66%. 🔥", kPct: [{ batter: "J. Hoo Lee", rc: -24, k: 44, hand: "L" }, { batter: "C. Schmitt", rc: -29, k: 39, hand: "R" }, { batter: "H. Ramos", rc: -25, k: 37, hand: "R" }] },
      { id: 1, name: "Robbie Ray", team: "SF", teamColor: "#FD5A1E", number: "#38", hand: "L", bp: { fd: 29.7, dk: 15.9, bf: 23.9, inn: 5.67, r: 2.30, h: 5.07, k: 5.48, bb: 1.96 }, innDist: [1,2,6,9,16,19,17,13,9,5,4], props: { k: { line: 5.5, proj: 5.6, side: "Over", oOdds: "-158", uOdds: "+118", record: "3-2", coverProb: 51, ev: -18, rating: 1 }, er: { line: 2.5, oOdds: "+140", uOdds: "-137" }, h: { line: 4.5, oOdds: "-137", uOdds: "+120" } }, pp: { line: 6 }, verdict: "LESS", confidence: 35, verdictNote: "Proyección 5.6 bajo PP de 6. EV -18%. ⭐ — evitar ❌", kPct: [{ batter: "O. Lopez", rc: -1, k: 21, hand: "R" }, { batter: "H. Hernandez", rc: -6, k: 21, hand: "R" }] },
    ],
  },
  {
    id: 3, label: "MIN @ TB", time: "4:10 PM",
    awayTeam: "MIN", homeTeam: "TB", awayWinPct: 46, homeWinPct: 54,
    awayColor: "#C6011F", homeColor: "#092C5C",
    bestPlay: { name: "S. McClanahan", play: "LESS 5 Ks", note: "Under 4/4 esta temporada · Cover 60%" },
    pitchers: [
      { id: 0, name: "Bailey Ober", team: "MIN", teamColor: "#C6011F", number: "#17", hand: "R", bp: { fd: 23.3, dk: 12.0, bf: 22.3, inn: 5.23, r: 2.53, h: 5.11, k: 4.15, bb: 1.63 }, innDist: [2,5,13,19,20,17,12,7,3,1,1], props: { k: { line: 4.5, proj: 4.5, side: "Over", oOdds: "+124", uOdds: "-166", record: "2-3", coverProb: 53, ev: 19, rating: 4 }, er: { line: 2.5, oOdds: "-109", uOdds: "+100" }, h: { line: 5.5, oOdds: "+124", uOdds: "-150" } }, pp: { line: 4 }, verdict: "MORE", confidence: 58, verdictNote: "Proyección exacta en BPros pero PP es 4 — Δ0.5. EV +19%. ⚠️", kPct: [{ batter: "J. Caminero", rc: -7, k: 13, hand: "R" }, { batter: "Y. Diaz", rc: -9, k: 9, hand: "R" }] },
      { id: 1, name: "S. McClanahan", team: "TB", teamColor: "#092C5C", number: "#18", hand: "L", bp: { fd: 27.9, dk: 15.3, bf: 21.7, inn: 5.16, r: 2.12, h: 4.51, k: 5.32, bb: 1.82 }, innDist: [1,3,7,12,15,18,16,12,8,5,4], props: { k: { line: 5.5, proj: 5.1, side: "Under", oOdds: "+120", uOdds: "-160", record: "0-4", coverProb: 60, ev: -2, rating: 2 }, er: { line: 2.5, oOdds: "+131", uOdds: "-166" }, h: { line: 4.5, oOdds: "-121", uOdds: "-107" } }, pp: { line: 5 }, verdict: "LESS", confidence: 70, verdictNote: "Under 4/4 esta temporada. Cover 60%. Proyección 5.1 bajo línea. 🔥", kPct: [{ batter: "V. Caratini", rc: -19, k: 30, hand: "S" }, { batter: "J. Bell", rc: -25, k: 33, hand: "S" }] },
    ],
  },
  {
    id: 4, label: "WSH @ CWS", time: "4:10 PM",
    awayTeam: "WSH", homeTeam: "CWS", awayWinPct: 45, homeWinPct: 55,
    awayColor: "#AB0003", homeColor: "#27251F",
    bestPlay: { name: "Noah Schultz", play: "LESS 5 Ks", note: "EV +34% · Cover 68% · ⭐⭐⭐⭐⭐ · Δ1.2 🔥🔥" },
    pitchers: [
      { id: 0, name: "Jake Irvin", team: "WSH", teamColor: "#AB0003", number: "#27", hand: "R", bp: { fd: 23.9, dk: 12.2, bf: 22.1, inn: 5.05, r: 2.68, h: 4.90, k: 4.81, bb: 2.20 }, innDist: [1,4,9,14,19,18,16,10,5,3,2], props: { k: { line: 4.5, proj: 4.1, side: "Under", oOdds: "+108", uOdds: "-144", record: "5-0", coverProb: 61, ev: 3, rating: 3 }, er: { line: 2.5, oOdds: "-111", uOdds: "-111" }, h: { line: 4.5, oOdds: "-125", uOdds: "+123" } }, pp: { line: 4 }, verdict: "LESS", confidence: 72, verdictNote: "Record 5-0 Over — PERO proyección 4.1 bajo PP de 4. EV +3%. ⚠️", kPct: [{ batter: "C. Montgomery", rc: 18, k: -4, hand: "L" }, { batter: "E. Pereira", rc: 17, k: 0, hand: "R" }] },
      { id: 1, name: "Noah Schultz", team: "CWS", teamColor: "#27251F", number: "#22", hand: "L", bp: { fd: 28.0, dk: 15.3, bf: 21.6, inn: 5.14, r: 2.02, h: 4.32, k: 5.22, bb: 2.16 }, innDist: [1,3,7,12,16,18,16,11,9,5,3], props: { k: { line: 4.5, proj: 3.8, side: "Under", oOdds: "-130", uOdds: "-102", record: "1-1", coverProb: 68, ev: 34, rating: 5 }, er: { line: 2.5, oOdds: "+170", uOdds: "-179" }, h: { line: 4.5, oOdds: "+109", uOdds: "-135" } }, pp: { line: 5 }, verdict: "LESS", confidence: 88, verdictNote: "EV +34% — mejor valor del día. Cover 68%. ⭐⭐⭐⭐⭐ Δ1.2. Play élite. 🔥🔥", kPct: [{ batter: "J. Young", rc: 8, k: -2, hand: "R" }, { batter: "C. Abrams", rc: -13, k: 12, hand: "L" }] },
    ],
  },
  {
    id: 5, label: "ATH @ TEX", time: "7:05 PM",
    awayTeam: "ATH", homeTeam: "TEX", awayWinPct: 46, homeWinPct: 54,
    awayColor: "#003831", homeColor: "#003278",
    bestPlay: { name: "MacKenzie Gore", play: "LESS 7 Ks", note: "EV +14% · Cover 57% · Δ0.8 🟢" },
    pitchers: [
      { id: 0, name: "Jeffrey Springs", team: "ATH", teamColor: "#003831", number: "#59", hand: "L", bp: { fd: 24.5, dk: 12.7, bf: 22.2, inn: 5.23, r: 2.43, h: 4.75, k: 4.41, bb: 1.97 }, innDist: [2,6,11,17,18,18,12,9,5,2,1], props: { k: { line: 5.5, proj: 4.6, side: "Under", oOdds: "+138", uOdds: "-186", record: "3-2", coverProb: 52, ev: -20, rating: 1 }, er: { line: 2.5, oOdds: "+108", uOdds: "-140" }, h: { line: 4.5, oOdds: "-116", uOdds: "+108" } }, pp: { line: 5 }, verdict: "LESS", confidence: 38, verdictNote: "EV -20% muy negativo. ⭐ — Evitar ❌", kPct: [{ batter: "J. Burger", rc: 0, k: -11, hand: "R" }, { batter: "C. Seager", rc: -11, k: -6, hand: "L" }] },
      { id: 1, name: "MacKenzie Gore", team: "TEX", teamColor: "#003278", number: "#1", hand: "L", bp: { fd: 32.0, dk: 17.7, bf: 22.8, inn: 5.46, r: 2.26, h: 4.70, k: 6.39, bb: 2.01 }, innDist: [0,1,3,6,11,15,17,16,12,9,10], props: { k: { line: 6.5, proj: 6.2, side: "Under", oOdds: "-132", uOdds: "+100", record: "3-2", coverProb: 57, ev: 14, rating: 4 }, er: { line: 1.5, oOdds: "-150", uOdds: "+132" }, h: { line: 4.5, oOdds: "-103", uOdds: "-110" } }, pp: { line: 7 }, verdict: "LESS", confidence: 74, verdictNote: "Proyección 6.2 vs PP 7 = Δ0.8 🟢. EV +14%. 🔥", kPct: [{ batter: "Z. Gelof", rc: -9, k: 26, hand: "R" }, { batter: "N. Kurtz", rc: -17, k: 23, hand: "L" }] },
    ],
  },
  {
    id: 6, label: "PIT @ MIL", time: "7:10 PM",
    awayTeam: "PIT", homeTeam: "MIL", awayWinPct: 44, homeWinPct: 56,
    awayColor: "#FDB827", homeColor: "#12284B",
    bestPlay: { name: "J. Misiorowski", play: "LESS 7.5 Ks", note: "EV +20% · Cover 69% · Δ1.1 🟢🔥" },
    pitchers: [
      { id: 0, name: "Mitch Keller", team: "PIT", teamColor: "#FDB827", number: "#23", hand: "R", bp: { fd: 21.8, dk: 11.0, bf: 21.3, inn: 4.89, r: 2.55, h: 4.65, k: 4.25, bb: 2.25 }, innDist: [2,6,12,18,19,17,13,7,3,2,1], props: { k: { line: 4.5, proj: 4.6, side: "Over", oOdds: "+100", uOdds: "-132", record: "1-4", coverProb: 52, ev: 4, rating: 3 }, er: { line: 2.5, oOdds: "+101", uOdds: "-115" }, h: { line: 4.5, oOdds: "-130", uOdds: "+117" } }, pp: { line: 4.5 }, verdict: "MORE", confidence: 52, verdictNote: "Δ0.1 Push Risk máximo. EV +4% pero record 1-4 Under. Evitar. ⚠️", kPct: [{ batter: "J. Bauers", rc: 11, k: -17, hand: "L" }, { batter: "W. Contreras", rc: 6, k: -11, hand: "L" }] },
      { id: 1, name: "J. Misiorowski", team: "MIL", teamColor: "#12284B", number: "#32", hand: "R", bp: { fd: 36.7, dk: 21.3, bf: 21.7, inn: 5.22, r: 1.73, h: 3.51, k: 7.67, bb: 2.58 }, innDist: [0,1,2,3,6,9,12,15,14,14,24], props: { k: { line: 7.5, proj: 6.4, side: "Under", oOdds: "+104", uOdds: "-138", record: "4-1", coverProb: 69, ev: 20, rating: 4 }, er: { line: 1.5, oOdds: "-125", uOdds: "-104" }, h: { line: 3.5, oOdds: "+104", uOdds: "-120" } }, pp: { line: 7.5 }, verdict: "LESS", confidence: 85, verdictNote: "EV +20% · Cover 69% · Δ1.1 🟢. PIT poncha mucho menos vs Misiorowski. 🔥", kPct: [{ batter: "R. O'Hearn", rc: -19, k: 70, hand: "L" }, { batter: "J. Mangum", rc: -36, k: 112, hand: "S" }] },
    ],
  },
  {
    id: 7, label: "LAA @ KC", time: "7:10 PM",
    awayTeam: "LAA", homeTeam: "KC", awayWinPct: 42, homeWinPct: 58,
    awayColor: "#BA0021", homeColor: "#004687",
    bestPlay: { name: "Walbert Urena", play: "LESS 3.5 Ks", note: "EV +9% · Cover 59% · Δ0.3 ⚠️" },
    pitchers: [
      { id: 0, name: "Walbert Urena", team: "LAA", teamColor: "#BA0021", number: "#57", hand: "R", bp: { fd: 19.1, dk: 9.9, bf: 19.0, inn: 4.42, r: 2.03, h: 3.73, k: 3.49, bb: 2.34 }, innDist: [4,10,19,21,19,14,8,4,2,1,0], props: { k: { line: 3.5, proj: 3.2, side: "Under", oOdds: "-112", uOdds: "-118", record: "1-0", coverProb: 59, ev: 9, rating: 3 }, er: { line: 2.5, oOdds: "-121", uOdds: "+101" }, h: { line: 5.5, oOdds: "+107", uOdds: "-139" } }, pp: { line: 3.5 }, verdict: "LESS", confidence: 60, verdictNote: "Proyección 3.2 vs PP 3.5 = Δ0.3. EV +9%. Record 1-0 — poca muestra. ⚠️", kPct: [{ batter: "I. Collins", rc: 11, k: -5, hand: "S" }, { batter: "B. Witt Jr.", rc: 7, k: -8, hand: "R" }] },
      { id: 1, name: "Cole Ragans", team: "KC", teamColor: "#004687", number: "#55", hand: "L", bp: { fd: 30.6, dk: 16.9, bf: 21.8, inn: 5.05, r: 2.29, h: 4.11, k: 6.58, bb: 2.57 }, innDist: [1,2,3,6,10,13,15,14,13,10,13], props: { k: { line: 6.5, proj: 7.0, side: "Over", oOdds: "-112", uOdds: "-118", record: "1-4", coverProb: 56, ev: 6, rating: 3 }, er: { line: 2.5, oOdds: "+129", uOdds: "-169" }, h: { line: 3.5, oOdds: "-164", uOdds: "+125" } }, pp: { line: 6.5 }, verdict: "MORE", confidence: 58, verdictNote: "Proyección 7.0 supera línea pero record 1-4 Under — señales muy mixtas. Δ0.5. ⚠️", kPct: [{ batter: "V. Grissom", rc: 1, k: 31, hand: "R" }, { batter: "J. Soler", rc: -6, k: 21, hand: "R" }] },
    ],
  },
  {
    id: 8, label: "NYY @ HOU", time: "7:10 PM",
    awayTeam: "NYY", homeTeam: "HOU", awayWinPct: 58, homeWinPct: 42,
    awayColor: "#003087", homeColor: "#EB6E1F",
    bestPlay: { name: "Mike Burrows", play: "MORE 5 Ks", note: "EV +17% · Cover 54% · Δ0.9 🟢" },
    pitchers: [
      { id: 0, name: "Ryan Weathers", team: "NYY", teamColor: "#003087", number: "#40", hand: "L", bp: { fd: 25.3, dk: 13.1, bf: 22.1, inn: 5.03, r: 2.67, h: 5.23, k: 5.12, bb: 2.00 }, innDist: [1,3,7,13,17,18,17,12,7,4,3], props: { k: { line: 5.5, proj: 5.7, side: "Over", oOdds: "+110", uOdds: "-146", record: "4-1", coverProb: 51, ev: 7, rating: 3 }, er: { line: 2.5, oOdds: "+104", uOdds: "-120" }, h: { line: 5.5, oOdds: "+111", uOdds: "-141" } }, pp: { line: 5 }, verdict: "MORE", confidence: 65, verdictNote: "Proyección 5.7 supera PP 5 — Δ0.7 🟢. EV +7%. Record 4-1 Over. ⚠️", kPct: [{ batter: "Y. Diaz", rc: -2, k: 31, hand: "R" }, { batter: "J. Altuve", rc: -7, k: 40, hand: "R" }, { batter: "C. Vazquez", rc: -3, k: 22, hand: "R" }] },
      { id: 1, name: "Mike Burrows", team: "HOU", teamColor: "#EB6E1F", number: "#50", hand: "R", bp: { fd: 23.2, dk: 11.9, bf: 21.4, inn: 4.90, r: 2.62, h: 4.70, k: 4.74, bb: 2.22 }, innDist: [2,5,10,14,18,16,16,10,5,3,2], props: { k: { line: 5.5, proj: 5.9, side: "Over", oOdds: "+118", uOdds: "-158", record: "3-2", coverProb: 54, ev: 17, rating: 4 }, er: { line: 2.5, oOdds: "-120", uOdds: "+109" }, h: { line: 4.5, oOdds: "-135", uOdds: "+108" } }, pp: { line: 5 }, verdict: "MORE", confidence: 73, verdictNote: "Proyección 5.9 supera PP 5 — Δ0.9 🟢. EV +17%. ⭐⭐⭐⭐ 🔥", kPct: [{ batter: "J. Altuve", rc: -7, k: 40, hand: "R" }, { batter: "Y. Diaz", rc: -2, k: 31, hand: "R" }, { batter: "C. Vazquez", rc: -3, k: 22, hand: "R" }] },
    ],
  },
];

const TABS = ["Proyecciones", "Props / Líneas", "K% Lineup", "Resumen"];
const MAX_PICKS = 6;
const PP_PAYOUTS = {
  power: { 2: 3, 3: 6, 4: 10, 5: 20, 6: 37.5 },
  flex: { 6: { 6: 25, 5: 2, 4: 0.4 }, 5: { 5: 10, 4: 2, 3: 0.4 }, 4: { 4: 6, 3: 1.5 }, 3: { 3: 3 }, 2: { 2: 3 } },
};

// ============================================================
// SIGNAL ANALYSIS — Alerta de Señales Mixtas + Filtro Coherencia
// ============================================================
function analyzeSignals(pitcher) {
  const { props, pp, verdict } = pitcher;
  const { k } = props;
  const alerts = [];
  const diff = Math.abs(k.proj - pp.line);

  // Parse record
  const [overW, underW] = k.record.split("-").map(Number);
  const totalGames = overW + underW;
  const historicalSide = overW > underW ? "Over" : underW > overW ? "Under" : null;

  // 1. Proyección vs historial contradice al veredicto
  if (historicalSide && totalGames >= 3) {
    const projSide = k.proj > pp.line ? "Over" : "Under";
    if (historicalSide !== projSide) {
      alerts.push({ type: "mixed", text: "Proyección dice " + projSide + " pero historial " + k.record + " apunta al " + historicalSide });
    }
  }

  // 2. EV negativo pero jugando
  if (k.ev < 0) {
    alerts.push({ type: "ev", text: "EV negativo (" + k.ev + "%) — la casa tiene ventaja en esta línea" });
  }

  // 3. Cover prob menor de 55%
  if (k.coverProb < 55) {
    alerts.push({ type: "cover", text: "Cover prob " + k.coverProb + "% — casi un volado, sin ventaja real" });
  }

  // 4. Sin ventaja de línea entre BPros y PP
  if (k.line === pp.line) {
    alerts.push({ type: "line", text: "Línea BPros igual a PP (" + pp.line + ") — sin diferencia de precio" });
  }

  // 5. Muestra muy pequeña (menos de 2 juegos)
  if (totalGames < 2) {
    alerts.push({ type: "sample", text: "Muestra muy pequeña (" + k.record + ") — historial no es confiable" });
  }

  // 6. Push risk
  const pushAlert = diff <= 0.2;

  // Coherence score
  const isMixed = alerts.length >= 2;
  const isPushOnly = alerts.length === 0 && pushAlert;
  const isClean = alerts.length === 0 && !pushAlert;

  return { alerts, isMixed, isPushOnly, isClean, pushAlert, diff };
}

function SignalCard({ pitcher }) {
  const { alerts, isMixed, isPushOnly, isClean, pushAlert, diff } = analyzeSignals(pitcher);

  if (isClean) {
    return (
      <div style={{ background: "rgba(34,197,94,0.08)", border: "1px solid rgba(34,197,94,0.3)", borderRadius: 12, padding: "12px 14px" }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: "#22c55e", marginBottom: 4 }}>✅ Pick Limpio</div>
        <div style={{ fontSize: 12, color: "#94a3b8" }}>Todos los datos apuntan al mismo lado. Sin contradicciones detectadas.</div>
      </div>
    );
  }

  if (isPushOnly) {
    return (
      <div style={{ background: "rgba(251,191,36,0.08)", border: "1px solid rgba(251,191,36,0.3)", borderRadius: 12, padding: "12px 14px" }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: "#fbbf24", marginBottom: 4 }}>⚠️ Push Risk — Δ{diff.toFixed(1)} Ks</div>
        <div style={{ fontSize: 12, color: "#94a3b8" }}>La proyección está muy cerca de la línea PP. Considera buscar una línea más baja antes de jugar.</div>
      </div>
    );
  }

  return (
    <div style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.35)", borderRadius: 12, padding: "12px 14px" }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: "#ef4444", marginBottom: 8 }}>🚨 Señales Mixtas Detectadas</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
        {alerts.map((a, i) => (
          <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
            <span style={{ color: "#ef4444", fontSize: 12, marginTop: 1 }}>•</span>
            <span style={{ fontSize: 12, color: "#fca5a5", lineHeight: 1.4 }}>{a.text}</span>
          </div>
        ))}
        {pushAlert && (
          <div style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
            <span style={{ color: "#fbbf24", fontSize: 12, marginTop: 1 }}>•</span>
            <span style={{ fontSize: 12, color: "#fde68a", lineHeight: 1.4 }}>Push Risk: proyección a solo Δ{diff.toFixed(1)} Ks de la línea</span>
          </div>
        )}
      </div>
      <div style={{ marginTop: 10, paddingTop: 10, borderTop: "1px solid rgba(239,68,68,0.2)", fontSize: 11, color: "#ef4444", fontWeight: 600 }}>
        🔒 Filtro de Coherencia: considera pasar este pick o jugar con monto reducido
      </div>
    </div>
  );
}

function getPushRisk(proj, ppLine) {
  const diff = Math.abs(proj - ppLine);
  if (diff <= 0.2) return { level: "high", color: "#ef4444", label: "🔴 Push Risk" };
  if (diff <= 0.5) return { level: "mid", color: "#f97316", label: "🟡 Precaución" };
  return { level: "low", color: "#22c55e", label: "🟢 Edge Claro" };
}

function Stars({ n }) {
  return <div style={{ display: "flex", gap: 2 }}>{[0,1,2,3,4].map(i => <span key={i} style={{ color: i < n ? "#fbbf24" : "#334155", fontSize: 13 }}>★</span>)}</div>;
}

function ConfBar({ pct, color }) {
  return <div style={{ width: "100%", height: 8, background: "rgba(255,255,255,0.08)", borderRadius: 4, overflow: "hidden" }}><div style={{ width: pct + "%", height: "100%", background: color, borderRadius: 4 }} /></div>;
}

function PushRiskBar({ proj, ppLine }) {
  const diff = Math.abs(proj - ppLine);
  const risk = getPushRisk(proj, ppLine);
  const safePct = Math.min((diff / 1.2) * 100, 100);
  return (
    <div style={{ background: risk.color + "15", border: "1px solid " + risk.color + "44", borderRadius: 12, padding: "12px 14px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: risk.color }}>{risk.label}</div>
        <div style={{ fontSize: 13, fontWeight: 700, color: "#f1f5f9" }}>Δ {diff.toFixed(1)} Ks</div>
      </div>
      <div style={{ position: "relative", height: 10, background: "rgba(255,255,255,0.07)", borderRadius: 5, overflow: "hidden", marginBottom: 6 }}>
        <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: safePct + "%", background: "linear-gradient(90deg, #ef4444, #f97316, #22c55e)", borderRadius: 5 }} />
        <div style={{ position: "absolute", top: 0, bottom: 0, width: 3, left: "calc(" + safePct + "% - 1.5px)", background: "#fff", borderRadius: 2 }} />
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 9, color: "#64748b" }}><span>Push Risk</span><span>Edge Claro</span></div>
    </div>
  );
}

function InnChart({ dist, color }) {
  const max = Math.max(...dist);
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 3, height: 64 }}>
      {dist.map((v, i) => (
        <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
          <div style={{ width: "100%", height: (max > 0 ? (v / max) * 52 : 0) + "px", background: v === max ? (color || "#fbbf24") : "rgba(255,255,255,0.15)", borderRadius: "2px 2px 0 0" }} />
          <span style={{ fontSize: 9, color: "#64748b" }}>{i}</span>
        </div>
      ))}
    </div>
  );
}

function KBar({ value }) {
  const pct = Math.min(Math.abs(value) / 112 * 100, 100);
  const isPos = value > 0;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
      <div style={{ width: 80, height: 6, background: "rgba(255,255,255,0.08)", borderRadius: 3, overflow: "hidden" }}>
        <div style={{ width: pct + "%", height: "100%", background: isPos ? "#f87171" : "#34d399", borderRadius: 3 }} />
      </div>
      <span style={{ fontSize: 12, color: isPos ? "#f87171" : "#34d399", fontWeight: 700, minWidth: 42 }}>{isPos ? "+" : ""}{value}%</span>
    </div>
  );
}

function ParlayBuilder({ parlay, onRemove, onClear }) {
  const [mode, setMode] = useState("power");
  const [amount, setAmount] = useState("10");
  const n = parlay.length;
  const amt = parseFloat(amount) || 0;
  const avgConf = n > 0 ? Math.round(parlay.reduce((a, p) => a + p.confidence, 0) / n) : 0;
  const powerPayout = n >= 2 ? PP_PAYOUTS.power[n] || null : null;
  const powerWin = powerPayout ? (amt * powerPayout).toFixed(2) : null;
  const flexTable = n >= 2 ? PP_PAYOUTS.flex[n] : null;
  const confColor = avgConf >= 75 ? "#22c55e" : avgConf >= 60 ? "#f97316" : "#ef4444";
  const mixedCount = parlay.filter(pit => analyzeSignals(pit).isMixed).length;

  return (
    <div style={{ padding: "0 16px 16px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
        <div><div style={{ fontSize: 14, fontWeight: 700, color: "#fbbf24" }}>🎯 Parlay Builder</div><div style={{ fontSize: 11, color: "#64748b" }}>{n}/{MAX_PICKS} picks</div></div>
        {n > 0 && <button onClick={onClear} style={{ padding: "5px 12px", borderRadius: 20, border: "1px solid rgba(248,113,113,0.4)", background: "rgba(248,113,113,0.1)", color: "#f87171", fontSize: 11, cursor: "pointer", fontWeight: 600 }}>Limpiar</button>}
      </div>

      {/* Mixed signal warning in parlay */}
      {mixedCount > 0 && (
        <div style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.3)", borderRadius: 12, padding: "10px 14px", marginBottom: 12 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: "#ef4444", marginBottom: 2 }}>🚨 {mixedCount} pick{mixedCount > 1 ? "s" : ""} con señales mixtas en tu parlay</div>
          <div style={{ fontSize: 11, color: "#fca5a5" }}>Revisa el análisis antes de confirmar. Estos picks tienen contradicciones detectadas.</div>
        </div>
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 14 }}>
        {Array.from({ length: MAX_PICKS }).map((_, i) => {
          const pick = parlay[i];
          const pr = pick ? getPushRisk(pick.props.k.proj, pick.pp.line) : null;
          const sig = pick ? analyzeSignals(pick) : null;
          return (
            <div key={i} style={{ borderRadius: 12, padding: "10px 14px", background: pick ? (pick.verdict === "MORE" ? "rgba(52,211,153,0.08)" : "rgba(248,113,113,0.08)") : "rgba(255,255,255,0.03)", border: pick ? ("1px solid " + (sig?.isMixed ? "rgba(239,68,68,0.5)" : pick.verdict === "MORE" ? "rgba(52,211,153,0.3)" : "rgba(248,113,113,0.3)")) : "1px dashed rgba(255,255,255,0.12)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              {pick ? (
                <>
                  <div>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <span style={{ fontSize: 10, color: "#64748b" }}>#{i+1}</span>
                      <span style={{ fontSize: 13, fontWeight: 700 }}>{pick.name}</span>
                      <span style={{ fontSize: 11, color: "#64748b" }}>{pick.team}</span>
                      {sig?.isMixed && <span style={{ fontSize: 9, color: "#ef4444", fontWeight: 700, padding: "1px 6px", background: "rgba(239,68,68,0.15)", borderRadius: 10 }}>🚨 MIXTO</span>}
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 4 }}>
                      <span style={{ fontSize: 11, fontWeight: 700, padding: "1px 8px", borderRadius: 20, background: pick.verdict === "MORE" ? "rgba(52,211,153,0.2)" : "rgba(248,113,113,0.2)", color: pick.verdict === "MORE" ? "#34d399" : "#f87171" }}>{pick.verdict} {pick.pp.line} Ks</span>
                      <span style={{ fontSize: 10, color: pr.color }}>{pr.label}</span>
                    </div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <div style={{ textAlign: "right" }}><div style={{ fontSize: 12, fontWeight: 700, color: pick.confidence >= 70 ? "#22c55e" : pick.confidence >= 55 ? "#f97316" : "#ef4444" }}>{pick.confidence}%</div><div style={{ fontSize: 10, color: pick.props.k.ev > 0 ? "#34d399" : "#f87171" }}>EV {pick.props.k.ev > 0 ? "+" : ""}{pick.props.k.ev}%</div></div>
                    <button onClick={() => onRemove(i)} style={{ width: 28, height: 28, borderRadius: "50%", border: "1px solid rgba(248,113,113,0.4)", background: "rgba(248,113,113,0.1)", color: "#f87171", cursor: "pointer", fontSize: 14, display: "flex", alignItems: "center", justifyContent: "center" }}>×</button>
                  </div>
                </>
              ) : <div style={{ fontSize: 12, color: "#334155", fontStyle: "italic" }}>Pick #{i+1} — Agrega un pitcher</div>}
            </div>
          );
        })}
      </div>

      {n >= 2 && (
        <>
          <div style={{ background: "rgba(255,255,255,0.04)", borderRadius: 12, padding: 12, marginBottom: 12 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}><div style={{ fontSize: 11, color: "#64748b", textTransform: "uppercase" }}>Confianza del Parlay</div><div style={{ fontSize: 14, fontWeight: 700, color: confColor }}>{avgConf}%</div></div>
            <ConfBar pct={avgConf} color={confColor} />
          </div>
          <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
            {["power","flex"].map(m => <button key={m} onClick={() => setMode(m)} style={{ flex: 1, padding: "10px", borderRadius: 12, border: "none", cursor: "pointer", background: mode === m ? "#fbbf24" : "rgba(255,255,255,0.07)", color: mode === m ? "#020617" : "#94a3b8", fontSize: 13, fontWeight: 700 }}>{m === "power" ? "⚡ Power Play" : "🔄 Flex Play"}</button>)}
          </div>
          <div style={{ background: "rgba(255,255,255,0.04)", borderRadius: 12, padding: 12, marginBottom: 12 }}>
            <div style={{ fontSize: 11, color: "#64748b", textTransform: "uppercase", marginBottom: 8 }}>Monto ($)</div>
            <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>{["5","10","20","50"].map(v => <button key={v} onClick={() => setAmount(v)} style={{ flex: 1, padding: "8px", borderRadius: 8, border: "none", cursor: "pointer", background: amount === v ? "#fbbf24" : "rgba(255,255,255,0.07)", color: amount === v ? "#020617" : "#94a3b8", fontSize: 13, fontWeight: 700 }}>${v}</button>)}</div>
            <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="Monto personalizado..." style={{ width: "100%", padding: "10px 12px", borderRadius: 8, border: "1px solid rgba(255,255,255,0.12)", background: "rgba(255,255,255,0.06)", color: "#f1f5f9", fontSize: 14, outline: "none" }} />
          </div>
          {mode === "power" && powerPayout && (
            <div style={{ background: "rgba(251,191,36,0.1)", border: "2px solid rgba(251,191,36,0.4)", borderRadius: 14, padding: 14, textAlign: "center" }}>
              <div style={{ fontSize: 10, color: "#fbbf24", textTransform: "uppercase", marginBottom: 6 }}>⚡ Power Play — {n} Picks</div>
              <div style={{ fontSize: 12, color: "#94a3b8", marginBottom: 8 }}>Todos los {n} picks deben acertar</div>
              <div style={{ display: "flex", justifyContent: "center", gap: 24, marginBottom: 8 }}>
                <div><div style={{ fontSize: 11, color: "#64748b" }}>Multiplicador</div><div style={{ fontSize: 28, fontWeight: 700, color: "#fbbf24" }}>{powerPayout}x</div></div>
                <div><div style={{ fontSize: 11, color: "#64748b" }}>Ganancia</div><div style={{ fontSize: 28, fontWeight: 700, color: "#22c55e" }}>${powerWin}</div></div>
              </div>
              <div style={{ fontSize: 11, color: "#64748b" }}>Entrada: ${amt.toFixed(2)} · Si falla 1 = pierde todo</div>
            </div>
          )}
          {mode === "flex" && flexTable && (
            <div style={{ background: "rgba(52,211,153,0.08)", border: "2px solid rgba(52,211,153,0.3)", borderRadius: 14, padding: 14 }}>
              <div style={{ fontSize: 10, color: "#34d399", textTransform: "uppercase", marginBottom: 10, textAlign: "center" }}>🔄 Flex Play — {n} Picks</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {Object.entries(flexTable).sort((a,b) => b[0]-a[0]).map(([hits, mult]) => {
                  const win = (amt * mult).toFixed(2);
                  const isTop = parseInt(hits) === n;
                  return (
                    <div key={hits} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 12px", borderRadius: 10, background: isTop ? "rgba(251,191,36,0.12)" : "rgba(255,255,255,0.04)", border: "1px solid " + (isTop ? "rgba(251,191,36,0.3)" : "rgba(255,255,255,0.06)") }}>
                      <div><div style={{ fontSize: 13, fontWeight: 700, color: isTop ? "#fbbf24" : "#f1f5f9" }}>{hits}/{n} aciertos {isTop ? "🏆" : ""}</div><div style={{ fontSize: 11, color: "#64748b" }}>{mult}x</div></div>
                      <div style={{ textAlign: "right" }}><div style={{ fontSize: 18, fontWeight: 700, color: isTop ? "#fbbf24" : "#34d399" }}>${win}</div><div style={{ fontSize: 10, color: "#64748b" }}>ganancia</div></div>
                    </div>
                  );
                })}
              </div>
              <div style={{ fontSize: 11, color: "#64748b", textAlign: "center", marginTop: 8 }}>Entrada: ${amt.toFixed(2)}</div>
            </div>
          )}
        </>
      )}
      {n < 2 && <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: 12, padding: 20, textAlign: "center", border: "1px dashed rgba(255,255,255,0.1)" }}><div style={{ fontSize: 24, marginBottom: 8 }}>⚾</div><div style={{ fontSize: 13, color: "#475569" }}>Agrega al menos 2 picks desde Scout o Ranking</div></div>}
    </div>
  );
}

export default function App() {
  const [activeGame, setActiveGame] = useState(0);
  const [activePitcher, setActivePitcher] = useState(0);
  const [activeTab, setActiveTab] = useState(0);
  const [view, setView] = useState("scout");
  const [parlay, setParlay] = useState([]);

  const game = GAMES[activeGame];
  const p = game.pitchers[activePitcher];
  const isMore = p.verdict === "MORE";
  const vc = isMore ? "#34d399" : "#f87171";
  const signals = analyzeSignals(p);

  function switchGame(i) { setActiveGame(i); setActivePitcher(0); setActiveTab(0); }
  function switchPitcher(i) { setActivePitcher(i); setActiveTab(0); }
  function addToParlay(pitcher) {
    if (parlay.length >= MAX_PICKS) return;
    if (parlay.find(pp => pp.name === pitcher.name && pp.team === pitcher.team)) return;
    setParlay([...parlay, pitcher]);
  }
  function removeFromParlay(index) { setParlay(parlay.filter((_, i) => i !== index)); }

  const alreadyInParlay = parlay.find(pp => pp.name === p.name && pp.team === p.team);
  const parlayFull = parlay.length >= MAX_PICKS;
  const allPitchers = GAMES.flatMap(g => g.pitchers.map(pit => ({ ...pit, gameLabel: g.label })));
  const ranked = [...allPitchers].sort((a, b) => b.confidence - a.confidence);

  return (
    <div style={{ minHeight: "100vh", background: "#020617", backgroundImage: "radial-gradient(ellipse at 15% 15%, rgba(0,92,92,0.15) 0%, transparent 55%), radial-gradient(ellipse at 85% 85%, rgba(196,30,58,0.1) 0%, transparent 55%)", color: "#f1f5f9", fontFamily: "system-ui, sans-serif", paddingBottom: 80 }}>
      <style>{`* { box-sizing: border-box; margin: 0; padding: 0; } input:focus { outline: none; }`}</style>

      <div style={{ padding: "14px 16px 10px", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: view === "scout" ? 8 : 0 }}>
          <div style={{ fontSize: 10, color: "#64748b", letterSpacing: 2, textTransform: "uppercase" }}>⚾ MLB Pitcher Scout</div>
          <div style={{ fontSize: 11, color: "#64748b" }}>Sáb, Abril 25</div>
        </div>
        {view === "scout" && (
          <>
            <div style={{ display: "flex", gap: 6, marginBottom: 10, overflowX: "auto", paddingBottom: 2 }}>
              {GAMES.map((g, i) => (
                <button key={g.id} onClick={() => switchGame(i)} style={{ flexShrink: 0, padding: "6px 10px", borderRadius: 10, cursor: "pointer", background: activeGame === i ? "rgba(251,191,36,0.12)" : "rgba(255,255,255,0.05)", border: "2px solid " + (activeGame === i ? "rgba(251,191,36,0.5)" : "rgba(255,255,255,0.08)"), color: activeGame === i ? "#fbbf24" : "#94a3b8", fontSize: 11, fontWeight: 700, textAlign: "center" }}>
                  <div>{g.label}</div>
                  <div style={{ fontSize: 9, fontWeight: 400, marginTop: 1, color: activeGame === i ? "#fbbf24" : "#64748b" }}>{g.time}</div>
                </button>
              ))}
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 11, fontWeight: 700, color: "#94a3b8", minWidth: 52 }}>{game.awayTeam} {game.awayWinPct}%</span>
              <div style={{ flex: 1, height: 6, background: game.homeColor, borderRadius: 3, overflow: "hidden" }}>
                <div style={{ width: game.awayWinPct + "%", height: "100%", background: game.awayColor, borderRadius: 3 }} />
              </div>
              <span style={{ fontSize: 11, fontWeight: 700, color: "#94a3b8", minWidth: 52, textAlign: "right" }}>{game.homeWinPct}% {game.homeTeam}</span>
            </div>
          </>
        )}
      </div>

      {view === "scout" && (
        <>
          <div style={{ display: "flex", gap: 10, padding: "12px 16px" }}>
            {game.pitchers.map((pit, i) => {
              const active = activePitcher === i;
              const pvc = pit.verdict === "MORE" ? "#34d399" : "#f87171";
              const pr = getPushRisk(pit.props.k.proj, pit.pp.line);
              const sig = analyzeSignals(pit);
              return (
                <button key={pit.id} onClick={() => switchPitcher(i)} style={{ flex: 1, padding: "12px 8px", borderRadius: 14, cursor: "pointer", background: active ? pit.teamColor + "22" : "rgba(255,255,255,0.04)", border: "2px solid " + (active ? pit.teamColor : "rgba(255,255,255,0.08)"), color: "#f1f5f9" }}>
                  <div style={{ fontSize: 10, color: "#94a3b8" }}>{pit.team} {pit.number}</div>
                  <div style={{ fontSize: 13, fontWeight: 700, marginTop: 2 }}>{pit.name}</div>
                  <div style={{ marginTop: 6, display: "flex", flexDirection: "column", gap: 4, alignItems: "center" }}>
                    <span style={{ fontSize: 11, fontWeight: 700, padding: "2px 10px", borderRadius: 20, background: pit.verdict === "MORE" ? "rgba(52,211,153,0.15)" : "rgba(248,113,113,0.15)", color: pvc, border: "1px solid " + pvc + "66" }}>{pit.verdict} {pit.pp.line} Ks</span>
                    <span style={{ fontSize: 10, fontWeight: 600, padding: "1px 8px", borderRadius: 20, background: pr.color + "20", color: pr.color, border: "1px solid " + pr.color + "44" }}>{pr.level === "high" ? "🔴 Push Risk" : pr.level === "mid" ? "🟡 Precaución" : "🟢 Edge"}</span>
                    {sig.isMixed && <span style={{ fontSize: 9, fontWeight: 700, padding: "1px 8px", borderRadius: 20, background: "rgba(239,68,68,0.2)", color: "#ef4444", border: "1px solid rgba(239,68,68,0.4)" }}>🚨 Señal Mixta</span>}
                    {sig.isClean && <span style={{ fontSize: 9, fontWeight: 700, padding: "1px 8px", borderRadius: 20, background: "rgba(34,197,94,0.15)", color: "#22c55e", border: "1px solid rgba(34,197,94,0.3)" }}>✅ Limpio</span>}
                  </div>
                </button>
              );
            })}
          </div>

          <div style={{ padding: "0 16px 12px" }}>
            <button onClick={() => { if (!alreadyInParlay && !parlayFull) addToParlay(p); }} disabled={!!alreadyInParlay || parlayFull} style={{ width: "100%", padding: "12px", borderRadius: 12, border: "1px solid " + (alreadyInParlay || parlayFull ? "rgba(255,255,255,0.08)" : vc + "44"), cursor: alreadyInParlay || parlayFull ? "not-allowed" : "pointer", background: alreadyInParlay || parlayFull ? "rgba(255,255,255,0.05)" : vc + "22", color: alreadyInParlay || parlayFull ? "#475569" : vc, fontSize: 13, fontWeight: 700 }}>
              {alreadyInParlay ? "✓ Ya está en el Parlay" : parlayFull ? "Parlay completo (6/6)" : "+ Agregar al Parlay — " + p.verdict + " " + p.pp.line + " Ks"}
            </button>
          </div>

          <div style={{ display: "flex", gap: 6, padding: "0 16px 12px", overflowX: "auto" }}>
            {TABS.map((t, i) => <button key={t} onClick={() => setActiveTab(i)} style={{ padding: "6px 14px", borderRadius: 20, border: "none", cursor: "pointer", background: activeTab === i ? "#fbbf24" : "rgba(255,255,255,0.07)", color: activeTab === i ? "#020617" : "#94a3b8", fontSize: 12, fontWeight: activeTab === i ? 700 : 500, whiteSpace: "nowrap" }}>{t}</button>)}
          </div>

          <div style={{ padding: "0 16px" }}>
            {activeTab === 0 && (
              <div>
                <div style={{ fontSize: 10, color: "#64748b", textTransform: "uppercase", marginBottom: 10 }}>📊 Ballpark Pal</div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 14 }}>
                  {[{ label: "Innings", value: p.bp.inn, hi: true }, { label: "Runs", value: p.bp.r }, { label: "Hits", value: p.bp.h }, { label: "Strikeouts", value: p.bp.k, hi: true }, { label: "Walks", value: p.bp.bb }, { label: "BF", value: p.bp.bf }].map(s => (
                    <div key={s.label} style={{ background: s.hi ? "rgba(251,191,36,0.1)" : "rgba(255,255,255,0.05)", border: "1px solid " + (s.hi ? "rgba(251,191,36,0.35)" : "rgba(255,255,255,0.08)"), borderRadius: 10, padding: "10px 12px", textAlign: "center" }}>
                      <div style={{ fontSize: 10, color: "#64748b", textTransform: "uppercase" }}>{s.label}</div>
                      <div style={{ fontSize: 22, fontWeight: 700, color: s.hi ? "#fbbf24" : "#f1f5f9" }}>{s.value}</div>
                    </div>
                  ))}
                </div>
                <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
                  <div style={{ flex: 1, background: "rgba(59,130,246,0.12)", border: "1px solid rgba(59,130,246,0.3)", borderRadius: 10, padding: 10, textAlign: "center" }}><div style={{ fontSize: 10, color: "#60a5fa", textTransform: "uppercase" }}>FD</div><div style={{ fontSize: 22, fontWeight: 700, color: "#60a5fa" }}>{p.bp.fd}</div></div>
                  <div style={{ flex: 1, background: "rgba(168,85,247,0.12)", border: "1px solid rgba(168,85,247,0.3)", borderRadius: 10, padding: 10, textAlign: "center" }}><div style={{ fontSize: 10, color: "#c084fc", textTransform: "uppercase" }}>DK</div><div style={{ fontSize: 22, fontWeight: 700, color: "#c084fc" }}>{p.bp.dk}</div></div>
                </div>
                <div style={{ background: "rgba(255,255,255,0.04)", borderRadius: 12, padding: 14 }}>
                  <div style={{ fontSize: 10, color: "#64748b", textTransform: "uppercase", marginBottom: 8 }}>Distribución de Innings</div>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 9, color: "#475569", marginBottom: 4 }}>{p.innDist.map((v, i) => <span key={i}>{v}%</span>)}</div>
                  <InnChart dist={p.innDist} color={p.teamColor} />
                </div>
              </div>
            )}

            {activeTab === 1 && (
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <div style={{ background: "rgba(255,255,255,0.04)", borderRadius: 14, padding: 14, border: "1px solid rgba(255,255,255,0.08)" }}>
                  <div style={{ fontSize: 10, color: "#64748b", textTransform: "uppercase", marginBottom: 10 }}>BettingPros — Strikeouts</div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                    <div><div style={{ fontSize: 11, color: "#94a3b8" }}>Línea</div><div style={{ fontSize: 32, fontWeight: 700 }}>{p.props.k.line} <span style={{ fontSize: 14, color: "#64748b" }}>Ks</span></div></div>
                    <div style={{ textAlign: "right" }}><div style={{ fontSize: 11, color: "#94a3b8" }}>Proyección</div><div style={{ fontSize: 32, fontWeight: 700, color: vc }}>{p.props.k.proj}</div></div>
                  </div>
                  <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
                    {[{ label: "Over", value: p.props.k.oOdds }, { label: "Under", value: p.props.k.uOdds }, { label: "Record", value: p.props.k.record }].map(s => (
                      <div key={s.label} style={{ flex: 1, background: "rgba(255,255,255,0.05)", borderRadius: 8, padding: 8, textAlign: "center" }}>
                        <div style={{ fontSize: 9, color: "#64748b", textTransform: "uppercase" }}>{s.label}</div>
                        <div style={{ fontSize: 14, fontWeight: 700 }}>{s.value}</div>
                      </div>
                    ))}
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 9, color: "#64748b", textTransform: "uppercase", marginBottom: 4 }}>Cover Prob ({p.props.k.side})</div>
                      <ConfBar pct={p.props.k.coverProb} color={vc} />
                      <div style={{ fontSize: 13, fontWeight: 700, marginTop: 3 }}>{p.props.k.coverProb}%</div>
                    </div>
                    <div style={{ textAlign: "right", marginLeft: 16 }}>
                      <div style={{ fontSize: 9, color: "#64748b", textTransform: "uppercase", marginBottom: 4 }}>Bet Rating</div>
                      <Stars n={p.props.k.rating} />
                      <div style={{ fontSize: 11, color: p.props.k.ev > 0 ? "#34d399" : "#f87171", marginTop: 3 }}>EV: {p.props.k.ev > 0 ? "+" : ""}{p.props.k.ev}%</div>
                    </div>
                  </div>
                </div>

                <PushRiskBar proj={p.props.k.proj} ppLine={p.pp.line} />

                {/* SIGNAL CARD */}
                <SignalCard pitcher={p} />

                <div style={{ display: "flex", gap: 8 }}>
                  {[{ label: "Earned Runs", line: p.props.er.line, o: p.props.er.oOdds, u: p.props.er.uOdds }, { label: "Hits Allow.", line: p.props.h.line, o: p.props.h.oOdds, u: p.props.h.uOdds }].map(s => (
                    <div key={s.label} style={{ flex: 1, background: "rgba(255,255,255,0.04)", borderRadius: 12, padding: 12, border: "1px solid rgba(255,255,255,0.07)" }}>
                      <div style={{ fontSize: 10, color: "#64748b", marginBottom: 6 }}>{s.label}</div>
                      <div style={{ fontSize: 22, fontWeight: 700, marginBottom: 6 }}>{s.line}</div>
                      <div style={{ fontSize: 11, color: "#94a3b8" }}>O: {s.o}</div>
                      <div style={{ fontSize: 11, color: "#94a3b8" }}>U: {s.u}</div>
                    </div>
                  ))}
                </div>

                <div style={{ background: isMore ? "rgba(52,211,153,0.08)" : "rgba(248,113,113,0.08)", border: "2px solid " + vc + "44", borderRadius: 14, padding: 14 }}>
                  <div style={{ fontSize: 10, color: "#64748b", textTransform: "uppercase", marginBottom: 8 }}>PrizePicks</div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div><div style={{ fontSize: 36, fontWeight: 700 }}>{p.pp.line} <span style={{ fontSize: 14, color: "#64748b" }}>Ks</span></div><div style={{ fontSize: 11, color: "#94a3b8", marginTop: 2 }}>vs {p.props.k.line} BettingPros</div></div>
                    <div style={{ padding: "14px 20px", borderRadius: 12, textAlign: "center", background: isMore ? "rgba(52,211,153,0.2)" : "rgba(248,113,113,0.2)", border: "2px solid " + vc }}>
                      <div style={{ fontSize: 24, fontWeight: 700, color: vc }}>{p.verdict}</div>
                      <div style={{ fontSize: 10, color: "#94a3b8" }}>PLAY</div>
                    </div>
                  </div>
                </div>

                <div style={{ background: "rgba(251,191,36,0.08)", border: "1px solid rgba(251,191,36,0.25)", borderRadius: 12, padding: 12 }}>
                  <div style={{ fontSize: 10, color: "#fbbf24", marginBottom: 4 }}>💡 ANÁLISIS</div>
                  <div style={{ fontSize: 13, color: "#f1f5f9", lineHeight: 1.5 }}>{p.verdictNote}</div>
                </div>
              </div>
            )}

            {activeTab === 2 && (
              <div>
                <div style={{ fontSize: 10, color: "#64748b", textTransform: "uppercase", marginBottom: 10 }}>K% vs Lineup Oponente</div>
                <div style={{ display: "flex", gap: 12, marginBottom: 10, fontSize: 11, color: "#64748b" }}>
                  <span><span style={{ color: "#34d399" }}>■</span> Verde = menos Ks</span>
                  <span><span style={{ color: "#f87171" }}>■</span> Rojo = más Ks</span>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                  {p.kPct.map((b, i) => (
                    <div key={i} style={{ background: "rgba(255,255,255,0.04)", borderRadius: 10, padding: "10px 12px", display: "flex", alignItems: "center", justifyContent: "space-between", border: "1px solid " + (b.k > 20 ? "rgba(248,113,113,0.25)" : b.k < -20 ? "rgba(52,211,153,0.25)" : "rgba(255,255,255,0.06)") }}>
                      <div><div style={{ fontSize: 13, fontWeight: 600 }}>{b.batter}</div><div style={{ fontSize: 10, color: "#64748b" }}>RC: <span style={{ color: b.rc >= 0 ? "#34d399" : "#f87171" }}>{b.rc > 0 ? "+" : ""}{b.rc}</span> • {b.hand}</div></div>
                      <KBar value={b.k} />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 3 && (
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                <div style={{ fontSize: 10, color: "#64748b", textTransform: "uppercase" }}>Resumen — {game.label}</div>
                {game.pitchers.map(pit => {
                  const pvc = pit.verdict === "MORE" ? "#34d399" : "#f87171";
                  const pr = getPushRisk(pit.props.k.proj, pit.pp.line);
                  const diff = Math.abs(pit.props.k.proj - pit.pp.line);
                  const sig = analyzeSignals(pit);
                  return (
                    <div key={pit.id} style={{ background: "rgba(255,255,255,0.04)", borderRadius: 14, padding: 14, border: "1px solid " + (sig.isMixed ? "rgba(239,68,68,0.4)" : pvc + "33") }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                        <div>
                          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                            <div style={{ fontSize: 15, fontWeight: 700 }}>{pit.name}</div>
                            {sig.isMixed && <span style={{ fontSize: 9, fontWeight: 700, padding: "1px 6px", background: "rgba(239,68,68,0.2)", color: "#ef4444", borderRadius: 10 }}>🚨 MIXTO</span>}
                            {sig.isClean && <span style={{ fontSize: 9, fontWeight: 700, padding: "1px 6px", background: "rgba(34,197,94,0.15)", color: "#22c55e", borderRadius: 10 }}>✅ LIMPIO</span>}
                          </div>
                          <div style={{ fontSize: 11, color: "#64748b" }}>{pit.team} • {pit.hand}HP</div>
                        </div>
                        <div style={{ display: "flex", flexDirection: "column", gap: 4, alignItems: "flex-end" }}>
                          <span style={{ padding: "4px 12px", borderRadius: 20, fontSize: 12, fontWeight: 700, background: pit.verdict === "MORE" ? "rgba(52,211,153,0.15)" : "rgba(248,113,113,0.15)", color: pvc, border: "1px solid " + pvc + "66" }}>{pit.verdict} {pit.pp.line} Ks</span>
                          <span style={{ padding: "2px 10px", borderRadius: 20, fontSize: 10, fontWeight: 600, background: pr.color + "20", color: pr.color, border: "1px solid " + pr.color + "44" }}>{pr.label} · Δ{diff.toFixed(1)}</span>
                        </div>
                      </div>
                      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 6, marginBottom: 10 }}>
                        {[{ l: "BP K", v: pit.bp.k }, { l: "BPros", v: pit.props.k.line }, { l: "PP Line", v: pit.pp.line }, { l: "Cover", v: pit.props.k.coverProb + "%" }, { l: "EV", v: (pit.props.k.ev > 0 ? "+" : "") + pit.props.k.ev + "%" }, { l: "Inn", v: pit.bp.inn }].map(s => (
                          <div key={s.l} style={{ background: "rgba(255,255,255,0.04)", borderRadius: 8, padding: "6px 8px", textAlign: "center" }}>
                            <div style={{ fontSize: 9, color: "#64748b" }}>{s.l}</div>
                            <div style={{ fontSize: 14, fontWeight: 700 }}>{s.v}</div>
                          </div>
                        ))}
                      </div>
                      <ConfBar pct={pit.confidence} color={pvc} />
                      <div style={{ fontSize: 12, fontWeight: 700, color: pvc, marginTop: 3, marginBottom: 6 }}>{pit.confidence}% confianza</div>
                      {sig.isMixed && (
                        <div style={{ background: "rgba(239,68,68,0.08)", borderRadius: 8, padding: "8px 10px", marginBottom: 8 }}>
                          {sig.alerts.map((a, i) => <div key={i} style={{ fontSize: 11, color: "#fca5a5", marginBottom: i < sig.alerts.length - 1 ? 4 : 0 }}>• {a.text}</div>)}
                        </div>
                      )}
                      <div style={{ fontSize: 12, color: "#94a3b8", lineHeight: 1.5 }}>{pit.verdictNote}</div>
                    </div>
                  );
                })}
                <div style={{ background: "rgba(251,191,36,0.1)", border: "2px solid rgba(251,191,36,0.4)", borderRadius: 14, padding: 14, textAlign: "center" }}>
                  <div style={{ fontSize: 10, color: "#fbbf24", textTransform: "uppercase", marginBottom: 6 }}>🏆 Mejor Play</div>
                  <div style={{ fontSize: 19, fontWeight: 700, color: "#fbbf24" }}>{game.bestPlay.name} — {game.bestPlay.play}</div>
                  <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 4 }}>{game.bestPlay.note}</div>
                </div>
              </div>
            )}
          </div>
        </>
      )}

      {view === "parlay" && <ParlayBuilder parlay={parlay} onRemove={removeFromParlay} onClear={() => setParlay([])} />}

      {view === "ranking" && (
        <div style={{ padding: "16px" }}>
          <div style={{ fontSize: 10, color: "#64748b", textTransform: "uppercase", letterSpacing: 1, marginBottom: 12 }}>🏆 Ranking del Día — {allPitchers.length} Pitchers</div>
          {ranked.map((pit, i) => {
            const pvc = pit.verdict === "MORE" ? "#34d399" : "#f87171";
            const pr = getPushRisk(pit.props.k.proj, pit.pp.line);
            const diff = Math.abs(pit.props.k.proj - pit.pp.line);
            const medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : "#" + (i+1);
            const inParlay = parlay.find(pp => pp.name === pit.name && pp.team === pit.team);
            const sig = analyzeSignals(pit);
            return (
              <div key={pit.id + pit.team} style={{ background: i === 0 ? "rgba(251,191,36,0.08)" : "rgba(255,255,255,0.04)", borderRadius: 12, padding: "12px 14px", marginBottom: 8, border: "1px solid " + (sig.isMixed ? "rgba(239,68,68,0.35)" : i === 0 ? "rgba(251,191,36,0.3)" : pvc + "22") }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ fontSize: 16 }}>{medal}</span>
                    <div>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <div style={{ fontSize: 14, fontWeight: 700 }}>{pit.name}</div>
                        {sig.isMixed && <span style={{ fontSize: 9, fontWeight: 700, padding: "1px 6px", background: "rgba(239,68,68,0.2)", color: "#ef4444", borderRadius: 10 }}>🚨</span>}
                        {sig.isClean && <span style={{ fontSize: 9, fontWeight: 700, padding: "1px 6px", background: "rgba(34,197,94,0.15)", color: "#22c55e", borderRadius: 10 }}>✅</span>}
                      </div>
                      <div style={{ fontSize: 10, color: "#64748b" }}>{pit.team} · {pit.gameLabel}</div>
                    </div>
                  </div>
                  <button onClick={() => { if (!inParlay && parlay.length < MAX_PICKS) addToParlay(pit); }} disabled={!!inParlay || parlay.length >= MAX_PICKS} style={{ padding: "5px 12px", borderRadius: 20, border: "none", cursor: inParlay || parlay.length >= MAX_PICKS ? "not-allowed" : "pointer", background: inParlay ? "rgba(255,255,255,0.05)" : pvc + "22", color: inParlay ? "#475569" : pvc, fontSize: 11, fontWeight: 700 }}>
                    {inParlay ? "✓ En parlay" : "+ Agregar"}
                  </button>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                  <div style={{ flex: 1 }}><ConfBar pct={pit.confidence} color={pvc} /></div>
                  <span style={{ fontSize: 12, fontWeight: 700, color: pvc, minWidth: 36 }}>{pit.confidence}%</span>
                </div>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
                  <span style={{ fontSize: 11, fontWeight: 700, padding: "1px 8px", borderRadius: 20, background: pit.verdict === "MORE" ? "rgba(52,211,153,0.15)" : "rgba(248,113,113,0.15)", color: pvc }}>{pit.verdict} {pit.pp.line} Ks</span>
                  <span style={{ fontSize: 10, color: pit.props.k.ev > 0 ? "#34d399" : "#f87171" }}>EV {pit.props.k.ev > 0 ? "+" : ""}{pit.props.k.ev}%</span>
                  <span style={{ fontSize: 10, color: "#94a3b8" }}>·</span>
                  <span style={{ fontSize: 10, color: pr.color }}>{pr.label} Δ{diff.toFixed(1)}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, background: "#0a0f1e", borderTop: "1px solid rgba(255,255,255,0.08)", display: "flex", padding: "8px 0 12px" }}>
        {[{ id: "scout", icon: "⚾", label: "Scout" }, { id: "parlay", icon: "🎯", label: parlay.length > 0 ? "Parlay (" + parlay.length + ")" : "Parlay" }, { id: "ranking", icon: "🏆", label: "Ranking" }].map(nav => (
          <button key={nav.id} onClick={() => setView(nav.id)} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 3, background: "none", border: "none", cursor: "pointer", padding: "4px 0" }}>
            <span style={{ fontSize: 20 }}>{nav.icon}</span>
            <span style={{ fontSize: 10, color: view === nav.id ? "#fbbf24" : "#475569", fontWeight: view === nav.id ? 700 : 400 }}>{nav.label}</span>
            {view === nav.id && <div style={{ width: 20, height: 2, background: "#fbbf24", borderRadius: 1 }} />}
          </button>
        ))}
      </div>
    </div>
  );
}
